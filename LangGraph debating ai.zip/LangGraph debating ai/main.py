from nodes import UserInputNode, AgentNode, MemoryNode, JudgeNode
import os
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    # Load environment variables
    load_dotenv()
    
    # Create nodes
    user_input = UserInputNode()
    agent_a = AgentNode("Scientist")
    agent_b = AgentNode("Philosopher")
    memory = MemoryNode()
    judge = JudgeNode()
    
    # Get topic from user
    topic = input("Enter topic for debate: ")
    
    # Start debate
    print(f"\nStarting debate between Scientist and Philosopher...")
    print(f"Topic: {topic}\n")
    
    # Initialize debate state
    current_speaker = agent_a
    turn_count = 0
    
    # Run debate: Scientist, Philosopher, then Judge
    # Get Scientist's argument
    print("\nSCIENTIST:")
    scientist_arg = agent_a.generate_argument(topic, memory.generate_memory_summary())
    memory.execute(scientist_arg, {"speaker": "Scientist", "turn": 1, "topic": topic})
    print("\n" + scientist_arg)
    
    # Get Philosopher's argument
    print("\nPHILOSPHER:")
    philosopher_arg = agent_b.generate_argument(topic, memory.generate_memory_summary())
    memory.execute(philosopher_arg, {"speaker": "Philosopher", "turn": 2, "topic": topic})
    print("\n" + philosopher_arg)
    
    # Get Judge's decision
    print("\nJUDGE:")
    judgment = judge.analyze_debate(memory.history)
    print(f"\nWinner: {judgment[0]}")
    print(f"Reason: {judgment[1]}")
    
    # The END
    print("\nTHE END")
    
    # Exit the program after judge's decision
    return

if __name__ == "__main__":
    main()
