import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

def generate_dag_diagram():
    # Create a directed graph
    G = nx.DiGraph()
    
    # Add nodes
    nodes = {
        'UserInput': 'UserInputNode',
        'AgentA': 'AgentA (Scientist)',
        'AgentB': 'AgentB (Philosopher)',
        'Memory': 'MemoryNode',
        'Judge': 'JudgeNode'
    }
    
    # Add edges
    edges = [
        ('UserInput', 'AgentA'),
        ('AgentA', 'Memory'),
        ('AgentB', 'Memory'),
        ('Memory', 'AgentB'),
        ('Memory', 'AgentA'),
        ('Memory', 'Judge')
    ]
    
    # Add nodes and edges to the graph
    for node, label in nodes.items():
        G.add_node(node, label=label)
    
    G.add_edges_from(edges)
    
    # Create figure and axis
    plt.figure(figsize=(10, 6))
    ax = plt.gca()
    
    # Position nodes
    pos = {
        'UserInput': (-1, 2),
        'AgentA': (0, 1),
        'AgentB': (2, 1),
        'Memory': (1, 0),
        'Judge': (1, -1)
    }
    
    # Draw nodes with labels
    nx.draw_networkx_nodes(G, pos, node_color='lightblue', node_size=2000)
    nx.draw_networkx_labels(G, pos, labels={node: nodes[node] for node in nodes})
    
    # Draw edges with arrows
    for edge in edges:
        arrow = FancyArrowPatch(
            posA=pos[edge[0]],
            posB=pos[edge[1]],
            arrowstyle='->',
            connectionstyle='arc3,rad=0.1',
            mutation_scale=20,
            color='black'
        )
        ax.add_patch(arrow)
    
    # Set plot limits
    plt.xlim(-2, 3)
    plt.ylim(-2, 3)
    
    # Remove axes
    plt.axis('off')
    
    # Save the figure
    plt.savefig('debate_dag.png', bbox_inches='tight')
    plt.close()
    
    print("DAG diagram generated as debate_dag.png")

if __name__ == "__main__":
    generate_dag_diagram()
