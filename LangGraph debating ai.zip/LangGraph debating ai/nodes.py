import google.generativeai as genai
from typing import Dict, Any, Optional
import json
from datetime import datetime
import os
import google.generativeai as genai

class UserInputNode:
    def __init__(self):
        self.topic = None

    def execute(self, message: str) -> str:
        self.topic = message
        return message

class AgentNode:
    def __init__(self, persona: str):
        self.persona = persona
        self.turn_count = 0
        self.topic = None
        genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
        self.model = genai.GenerativeModel('gemini-2.0-flash')
    
    def set_topic(self, topic: str):
        self.topic = topic
        
    def generate_argument(self, topic: str, memory: str) -> str:
        try:
            # Generate a context-aware argument
            prompt = f"""
            You are a {self.persona} debating the topic: {topic}
            Current debate state:
            {memory}
            
            Generate a well-structured, context-aware argument (700 words max) that:
            1. Clearly states your position with a strong opening that directly addresses the topic
            2. Provides 3-4 key supporting points with concrete evidence and examples
            3. Addresses counterarguments with specific rebuttals
            4. Maintains a professional and respectful tone
            5. Uses specific, relevant examples and evidence
            6. Concludes with a strong summary that ties back to the opening
            
            Consider the following context:
            - The historical context of AI development
            - Current technological capabilities and limitations
            - Ethical implications for humanity
            - Potential long-term consequences
            - Practical implementation challenges
            
            Organize the argument logically with clear paragraph breaks and smooth transitions.
            """
            
            response = self.model.generate_content(prompt)
            
            # Format the response with proper paragraph breaks
            text = response.text.strip()
            
            # Split into paragraphs and join with proper spacing
            paragraphs = text.split("\n")
            formatted_text = "\n\n".join([p.strip() for p in paragraphs if p.strip()])
            
            # Trim if too long
            words = formatted_text.split()
            if len(words) > 140:  # Rough word count (700 words)
                formatted_text = " ".join(words[:140])
            
            return formatted_text
        except Exception as e:
            print(f"Error generating argument: {str(e)}")
            raise



class MemoryNode:
    def __init__(self):
        self.history = []

    def execute(self, message: str, metadata: dict) -> dict:
        # Get the current turn count
        turn_count = metadata.get("turn_count", 1)
        
        # Store the message with proper metadata
        self.history.append({
            "speaker": metadata.get("speaker"),
            "content": message,
            "turn": turn_count,
            "timestamp": datetime.now().isoformat()
        })
        
        return {
            "memory": self.generate_memory_summary(),
            "history": self.history
        }

    def generate_memory_summary(self) -> str:
        # Generate a formatted summary of the debate history
        summary = "Debate History:\n"
        for item in self.history:
            summary += f"\n[Round {item['turn']}] {item['speaker']}:\n{item['content']}\n"
        return summary

class JudgeNode:
    def __init__(self):
        genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
        self.model = genai.GenerativeModel('gemini-2.0-flash')

    def analyze_debate(self, history: list) -> tuple:
        # Get the two arguments
        scientist_arg = history[0]['content']
        philosopher_arg = history[1]['content']
        
        prompt = f"""
        Evaluate these two arguments and decide which is stronger:
        
        Scientist's argument:
        {scientist_arg}
        
        Philosopher's argument:
        {philosopher_arg}
        
        Consider:
        - Logical consistency
        - Argument strength
        - Evidence provided
        
        Return in format: ("Winner", "Reason")
        """
        
        try:
            response = self.model.generate_content(prompt)
            winner, reason = eval(response.text.strip())
            return (winner, reason)
        except Exception as e:
            print(f"Error in judgment: {str(e)}")
            return ("Scientist", "More compelling arguments")

    def generate_summary(self, history: list) -> str:
        return "\n".join([
            f"[Round {item['turn']}] {item['speaker']}: {item['content']}"
            for item in history
        ])

    def log_debate(self, history: list, summary: str):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = f"debate_log_{timestamp}.txt"
        
        with open(log_file, "w") as f:
            f.write(f"Debate Topic: {history[0]['content']}\n\n")
            f.write(f"{summary}\n\n")
            f.write(f"Final Judgment:\n")
            f.write(f"Winner: {self.winner}\n")
            f.write(f"Reason: {self.reason}\n")

    def generate_summary(self, history: list) -> str:
        # Generate a summary of the debate
        return "\n".join([
            f"[Round {item['turn']}] {item['speaker']}: {item['content']}"
            for item in history
        ])

    def log_debate(self, history: list, summary: str):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = f"debate_log_{timestamp}.txt"
        
        with open(log_file, "w") as f:
            f.write(f"Debate Topic: {message.metadata.get('topic')}\n\n")
            f.write(f"{summary}\n\n")
            f.write(f"Final Judgment:\n")
            f.write(f"Winner: {self.winner}\n")
            f.write(f"Reason: {self.reason}\n")
